BUTTERCUP
Copyright 2016 by Francis Studio

Thank you! for downloading my font.

This font is free for PERSONAL USE ONLY.

Any commercial use of this font should need a commercial license. [Commercial license and Commercial font is not yet available. I will update you soon.]
If you have questions, reactions and comments please email me at francisstudio14@gmail.com
And I will gladly reply to it as soon as possible.

Thank you again!

Each stroke is made with love, Hope you love it!

Francis John | Francis Studio